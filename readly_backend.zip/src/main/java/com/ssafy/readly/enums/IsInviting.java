package com.ssafy.readly.enums;

/**
 * Allow(A), Reject(R)
 */
public enum IsInviting {
    a,r;
}