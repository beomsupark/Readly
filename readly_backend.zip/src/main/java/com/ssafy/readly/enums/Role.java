package com.ssafy.readly.enums;

/**
 * Leader(L), Member(M)
 */
public enum Role {
    L, M
}
