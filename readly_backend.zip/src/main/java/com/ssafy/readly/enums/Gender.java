package com.ssafy.readly.enums;

/**
 * Male(M), Female(F)
 */
public enum Gender {
    M, F
}
