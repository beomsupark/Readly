package com.ssafy.readly.enums;

/**
 * Google(G), Kakao(K), Instagram(I), Readly(R)
 */
public enum Social {
    G, K, I, R
}
