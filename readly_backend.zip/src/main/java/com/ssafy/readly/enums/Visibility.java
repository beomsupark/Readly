package com.ssafy.readly.enums;

/**
 * Alone(A), Every(E)
 */
public enum Visibility {
    A, E
}
