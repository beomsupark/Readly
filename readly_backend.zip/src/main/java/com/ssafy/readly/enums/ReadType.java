package com.ssafy.readly.enums;


/**
 * Reading(R), Done(D)
 */
public enum ReadType {
    R,D
}
