package com.ssafy.readly.enums;

/**
 * PhotoCard(P), Review(R)
 */
public enum ItemType {
    P, R
}
