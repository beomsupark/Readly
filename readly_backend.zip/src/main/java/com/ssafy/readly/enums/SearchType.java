package com.ssafy.readly.enums;

public enum SearchType {
    Like, TimeStamp
}
