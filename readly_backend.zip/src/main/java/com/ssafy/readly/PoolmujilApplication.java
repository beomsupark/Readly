package com.ssafy.readly;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PoolmujilApplication {

	public static void main(String[] args) {
		SpringApplication.run(PoolmujilApplication.class, args);
	}

}
