package com.ssafy.readly.dto.member;

public class FindMemberRequest {
    private String userName;
    private String userId;
    private String phoneNumber;
    private String email;
}
