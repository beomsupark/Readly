package com.ssafy.readly.dto.readbook;

import lombok.Data;

@Data
public class ReadBookRequestDTO {
    private int memberId;
    private int bookId;
}
