package com.ssafy.readly.repository.photocard;


import com.ssafy.readly.entity.PhotoCard;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PhotoCardRepository extends JpaRepository<PhotoCard, Integer> {

}
